import { useEffect, useMemo, useState } from 'react';
import {
  Sparkles,
  ScanLine,
  Target,
  Clock,
  ListChecks,
  Brain,
  Zap,
  ArrowRight,
  Focus,
  X,
  Play,
  ChevronDown,
  Timer,
  CheckCircle2,
  ArrowLeft,
  Gauge,
  CalendarClock,
  Lightbulb,
  Activity,
} from 'lucide-react';
import {
  DEMO_INPUT,
  FOCUS_COACHING,
  PRIORITY_META,
  PROCESSING_STEPS,
  type Priority,
  type Task,
} from './data/flowData';
import { EXAMPLE_PROMPTS, generatePlan } from './data/planParser';

const RAIL: Record<Priority, { rail: string; glow: string }> = {
  high: { rail: 'linear-gradient(180deg, #f43f5e, #fb923c)', glow: 'rgba(244,63,94,0.6)' },
  important: { rail: 'linear-gradient(180deg, #f59e0b, #f97316)', glow: 'rgba(245,158,11,0.55)' },
  quick: { rail: 'linear-gradient(180deg, #10b981, #2dd4bf)', glow: 'rgba(16,185,129,0.55)' },
};

type Phase = 'input' | 'processing' | 'dashboard';

const STEP_ICONS: Record<string, typeof ScanLine> = {
  scan: ScanLine,
  target: Target,
  clock: Clock,
  sparkles: Sparkles,
};

const FLOW_PILLARS = [
  { icon: Brain, label: 'Messy Thoughts', sub: 'Raw brain dump' },
  { icon: ScanLine, label: 'AI Understands', sub: 'Parses intent' },
  { icon: Target, label: 'AI Prioritizes', sub: 'Ranks by impact' },
  { icon: Clock, label: 'AI Estimates', sub: 'Time per task' },
  { icon: ListChecks, label: 'Action Plan', sub: 'Ready to execute' },
];

export default function App() {
  const [phase, setPhase] = useState<Phase>('input');
  const [input, setInput] = useState('');
  const [activeStep, setActiveStep] = useState(0);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [focusTask, setFocusTask] = useState<Task | null>(null);

  const startProcessing = () => {
    if (!input.trim()) return;
    setTasks(generatePlan(input));
    setPhase('processing');
    setActiveStep(0);
  };

  useEffect(() => {
    if (phase !== 'processing') return;
    if (activeStep >= PROCESSING_STEPS.length) {
      const t = setTimeout(() => setPhase('dashboard'), 500);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setActiveStep((s) => s + 1), 1100);
    return () => clearTimeout(t);
  }, [phase, activeStep]);

  const reset = () => {
    setPhase('input');
    setInput('');
    setTasks([]);
  };

  return (
    <div className="app-bg min-h-screen w-full text-slate-100">
      <Header onReset={reset} showReset={phase === 'dashboard'} />

      <main className="relative z-10 mx-auto max-w-6xl px-5 pb-24 sm:px-8">
        {phase === 'input' && (
          <Hero
            input={input}
            setInput={setInput}
            onStart={startProcessing}
          />
        )}

        {phase === 'processing' && (
          <Processing activeStep={activeStep} />
        )}

        {phase === 'dashboard' && (
          <Dashboard tasks={tasks} onReset={reset} onFocus={setFocusTask} />
        )}
      </main>

      {focusTask && (
        <FocusModal task={focusTask} onClose={() => setFocusTask(null)} />
      )}

      <Footer />
    </div>
  );
}

/* ---------------- Header ---------------- */
function Header({ onReset, showReset }: { onReset: () => void; showReset: boolean }) {
  return (
    <header className="sticky top-0 z-30 w-full">
      <div className="glass-strong border-b border-white/5">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-electric-600 to-cyan-500 shadow-lg shadow-electric-600/30">
              <Sparkles className="h-5 w-5 text-white" />
              <div className="absolute inset-0 rounded-xl ring-1 ring-white/20" />
            </div>
            <div className="leading-tight">
              <div className="font-display text-lg font-700 tracking-tight text-white">
                FlowPilot <span className="gradient-text">AI</span>
              </div>
              <div className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
                Your AI Chief of Staff
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 sm:flex">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              AI online
            </div>
            {showReset && (
              <button
                onClick={onReset}
                className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-500 text-slate-200 transition hover:bg-white/10 focus-ring"
              >
                <ArrowLeft className="h-3.5 w-3.5" /> New plan
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

/* ---------------- Hero ---------------- */
function Hero({
  input,
  setInput,
  onStart,
}: {
  input: string;
  setInput: (v: string) => void;
  onStart: () => void;
}) {
  const examples = EXAMPLE_PROMPTS;

  return (
    <section className="relative pt-16 sm:pt-24">
      {/* Floating orbs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-20 top-10 h-72 w-72 animate-float rounded-full bg-electric-600/20 blur-3xl" />
        <div className="absolute -right-10 top-32 h-80 w-80 animate-float rounded-full bg-cyan-500/15 blur-3xl [animation-delay:2s]" />
        <div className="absolute left-1/2 top-1/2 h-64 w-64 animate-drift rounded-full bg-fuchsia-500/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-3xl text-center">
        <div className="mb-5 inline-flex animate-fadeIn items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs text-slate-300">
          <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
          AI Chief of Staff · Plan in seconds
        </div>
        <h1 className="perspective font-display text-5xl font-700 leading-[1.05] tracking-tight text-white sm:text-7xl">
          <span className="inline-block animate-wordIn [animation-delay:0.05s] opacity-0">Turn </span>
          <span className="inline-block animate-wordIn [animation-delay:0.12s] opacity-0">chaos </span>
          <br className="hidden sm:block" />
          <span className="inline-block animate-wordIn [animation-delay:0.2s] opacity-0">into </span>
          <span className="gradient-text glow-text inline-block animate-wordIn [animation-delay:0.28s] opacity-0">clarity.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-xl animate-fadeIn text-base leading-relaxed text-slate-400 [animation-delay:0.4s] opacity-0 sm:text-lg">
          Tell us everything on your mind. AI will turn it into your next best actions.
        </p>
      </div>

      {/* Input card */}
      <div className="relative mx-auto mt-10 max-w-3xl animate-scaleIn">
        <div className="glass-strong gradient-border rounded-3xl p-2 shadow-2xl shadow-electric-600/10 transition hover:shadow-electric-600/20">
          <div className="rounded-2xl bg-ink-950/40 p-5 sm:p-6">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Tell me everything on your mind..."
              rows={5}
              className="w-full resize-none bg-transparent text-lg leading-relaxed text-slate-100 placeholder:text-slate-500 transition focus:outline-none focus:placeholder:text-slate-600"
            />
            <div className="mt-4 flex flex-col items-stretch gap-4 border-t border-white/5 pt-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2">
                {examples.map((ex) => (
                  <button
                    key={ex.label}
                    onClick={() => setInput(ex.text)}
                    className="rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-slate-300 transition hover:-translate-y-0.5 hover:border-electric-400/40 hover:bg-electric-500/10 hover:text-white focus-ring"
                  >
                    {ex.label}
                  </button>
                ))}
              </div>
              <button
                onClick={onStart}
                disabled={!input.trim()}
                className="btn-primary group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full px-6 py-3 text-sm font-600 text-white disabled:cursor-not-allowed disabled:opacity-40 focus-ring"
              >
                <Sparkles className="h-4 w-4" />
                Make My Day
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
              </button>
            </div>
          </div>
        </div>

        <button
          onClick={() => setInput(DEMO_INPUT)}
          className="mx-auto mt-4 flex animate-fadeIn items-center gap-1.5 text-xs text-slate-500 transition hover:text-slate-300 [animation-delay:0.5s] opacity-0"
        >
          <Lightbulb className="h-3.5 w-3.5" /> Try the demo input
        </button>
      </div>

      <FlowTransformation />
    </section>
  );
}

/* ---------------- Flow Transformation ---------------- */
function FlowTransformation() {
  return (
    <section className="relative mt-24 sm:mt-32">
      <div className="mb-10 text-center">
        <div className="text-xs uppercase tracking-[0.2em] text-slate-500">How it works</div>
        <h2 className="mt-2 font-display text-2xl font-600 text-white sm:text-3xl">
          From noise to a plan
        </h2>
      </div>
      <div className="relative grid grid-cols-2 gap-4 sm:grid-cols-5 sm:gap-3">
        {FLOW_PILLARS.map((p, i) => (
          <div key={p.label} className="relative">
            <div className="glass group h-full rounded-2xl p-4 text-center transition hover:-translate-y-1 hover:border-white/20">
              <div className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-electric-600/30 to-cyan-500/20 ring-1 ring-white/10">
                <p.icon className="h-5 w-5 text-cyan-300" />
              </div>
              <div className="text-sm font-600 text-white">{p.label}</div>
              <div className="mt-0.5 text-[11px] text-slate-400">{p.sub}</div>
            </div>
            {i < FLOW_PILLARS.length - 1 && (
              <div className="absolute -right-2 top-1/2 hidden -translate-y-1/2 sm:block">
                <ArrowRight className="h-4 w-4 text-electric-400/50" />
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------------- Processing ---------------- */
function Processing({ activeStep }: { activeStep: number }) {
  return (
    <section className="relative flex min-h-[60vh] flex-col items-center justify-center pt-10">
      <div className="relative grid place-items-center">
        {/* Orbit rings */}
        <div className="absolute h-64 w-64 animate-spinSlow rounded-full border border-electric-500/20" />
        <div className="absolute h-44 w-44 animate-spinSlow rounded-full border border-cyan-500/20 [animation-direction:reverse] [animation-duration:8s]" />

        {/* Core */}
        <div className="relative grid h-32 w-32 place-items-center">
          <div className="absolute inset-0 animate-pulseGlow rounded-full bg-gradient-to-br from-electric-600 to-cyan-500 blur-2xl" />
          <div className="relative grid h-24 w-24 place-items-center rounded-full bg-gradient-to-br from-electric-600 to-cyan-500 shadow-2xl shadow-electric-600/40">
            <Brain className="h-10 w-10 text-white" />
          </div>
        </div>
      </div>

      <div className="mt-12 w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="font-display text-xl font-600 text-white">AI is thinking…</div>
          <div className="text-sm text-slate-400">Structuring your day</div>
        </div>
        <div className="space-y-3">
          {PROCESSING_STEPS.map((step, i) => {
            const Icon = STEP_ICONS[step.icon];
            const done = i < activeStep;
            const active = i === activeStep;
            return (
              <div
                key={step.label}
                className={`flex items-center gap-3 rounded-xl border px-4 py-3 transition-all duration-500 ${
                  done
                    ? 'border-emerald-400/30 bg-emerald-500/10'
                    : active
                    ? 'border-electric-400/40 bg-electric-500/10'
                    : 'border-white/5 bg-white/[0.02] opacity-50'
                }`}
              >
                <div
                  className={`grid h-8 w-8 place-items-center rounded-lg ${
                    done
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : active
                      ? 'bg-electric-500/20 text-electric-300'
                      : 'bg-white/5 text-slate-500'
                  }`}
                >
                  {done ? <CheckCircle2 className="h-4 w-4 animate-scaleIn" /> : <Icon className={`h-4 w-4 ${active ? 'animate-pulse' : ''}`} />}
                </div>
                <span
                  className={`text-sm ${
                    done ? 'text-emerald-200' : active ? 'text-white' : 'text-slate-500'
                  }`}
                >
                  {step.label}
                </span>
                {active && (
                  <div className="ml-auto h-1.5 w-20 overflow-hidden rounded-full bg-white/10">
                    <div className="shimmer h-full w-full" />
                  </div>
                )}
                {done && (
                  <CheckCircle2 className="ml-auto h-4 w-4 text-emerald-400" />
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-6 h-1 overflow-hidden rounded-full bg-white/5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-electric-500 via-cyan-400 to-electric-500 transition-all duration-700 ease-out"
            style={{ width: `${(activeStep / PROCESSING_STEPS.length) * 100}%` }}
          />
        </div>
      </div>
    </section>
  );
}

/* ---------------- Dashboard ---------------- */
function Dashboard({
  tasks,
  onReset,
  onFocus,
}: {
  tasks: Task[];
  onReset: () => void;
  onFocus: (t: Task) => void;
}) {
  const stats = useMemo(() => {
    const totalMin = tasks.reduce((s, t) => s + t.durationMinutes, 0);
    const hours = Math.floor(totalMin / 60);
    const mins = totalMin % 60;
    const score = Math.min(
      99,
      Math.round(40 + tasks.reduce((s, t) => s + t.importance * 0.4 + (100 - t.urgency) * 0.1, 0) / tasks.length)
    );
    const focus = tasks.find((t) => t.priority === 'high') ?? tasks[0];
    return {
      totalMin,
      timeLabel: `${hours}h ${mins}m`,
      score,
      focus,
    };
  }, [tasks]);

  const groups: { key: Priority; tasks: Task[] }[] = [
    { key: 'high', tasks: tasks.filter((t) => t.priority === 'high') },
    { key: 'important', tasks: tasks.filter((t) => t.priority === 'important') },
    { key: 'quick', tasks: tasks.filter((t) => t.priority === 'quick') },
  ];

  return (
    <section className="animate-fadeIn pt-10">
      <div className="mb-8 flex flex-col gap-2 animate-slideUp">
        <div className="text-xs uppercase tracking-[0.2em] text-electric-400">Your action plan</div>
        <h2 className="font-display text-3xl font-700 text-white sm:text-4xl">
          Here's your day, <span className="gradient-text glow-text">organized.</span>
        </h2>
      </div>

      {/* Stats */}
      <div className="stagger grid grid-cols-2 gap-4 sm:grid-cols-4">
        <ProductivityScoreCard score={stats.score} />
        <StatCard
          icon={ListChecks}
          label="Total Tasks"
          value={`${tasks.length}`}
          accent="from-fuchsia-500 to-electric-500"
        />
        <StatCard
          icon={Clock}
          label="Total Time"
          value={stats.timeLabel}
          accent="from-cyan-500 to-teal-400"
        />
        <StatCard
          icon={Focus}
          label="Focus First"
          value={stats.focus.title}
          accent="from-amber-500 to-rose-500"
          compact
        />
      </div>

      {/* AI Decision Trail */}
      <DecisionTrail tasks={tasks} />

      {/* Task groups */}
      <div className="mt-12 space-y-10">
        {groups.map(
          (g) =>
            g.tasks.length > 0 && (
              <div key={g.key} className="animate-slideUp">
                <div className="mb-4 flex items-center gap-3">
                  <span
                    className={`h-2.5 w-2.5 rounded-full ${PRIORITY_META[g.key].dot}`}
                  />
                  <h3 className="font-display text-sm font-600 uppercase tracking-[0.18em] text-slate-300">
                    {PRIORITY_META[g.key].group}
                  </h3>
                  <div className="step-line h-px flex-1" />
                  <span className="text-xs text-slate-500">{g.tasks.length} tasks</span>
                </div>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  {g.tasks.map((t, i) => (
                    <TaskCard
                      key={t.id}
                      task={t}
                      index={i}
                      onFocus={() => onFocus(t)}
                    />
                  ))}
                </div>
              </div>
            )
        )}
      </div>

      <div className="mt-14 flex justify-center">
        <button
          onClick={onReset}
          className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-5 py-2.5 text-sm text-slate-300 transition hover:bg-white/10 focus-ring"
        >
          <ArrowLeft className="h-4 w-4" /> Plan a new day
        </button>
      </div>
    </section>
  );
}

function ProductivityScoreCard({ score }: { score: number }) {
  const r = 52;
  const circ = 2 * Math.PI * r;
  const offset = circ * (1 - score / 100);
  return (
    <div className="glass-strong card-hover relative col-span-2 flex items-center gap-4 overflow-hidden rounded-2xl p-5 hover:border-white/20 sm:col-span-1">
      <div className="pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br from-electric-600 to-cyan-500 opacity-20 blur-2xl" />
      <div className="relative grid h-24 w-24 shrink-0 place-items-center">
        <svg className="absolute inset-0 -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="8" />
          <circle
            cx="60"
            cy="60"
            r={r}
            fill="none"
            stroke="url(#scoreGrad)"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.22,1,0.36,1)' }}
          />
          <defs>
            <linearGradient id="scoreGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#22d3ee" />
            </linearGradient>
          </defs>
        </svg>
        <div className="text-center">
          <div className="font-display text-2xl font-700 text-white">{score}</div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400">/100</div>
        </div>
      </div>
      <div className="relative">
        <div className="mb-1 grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-electric-600 to-cyan-500 shadow-lg">
          <Gauge className="h-3.5 w-3.5 text-white" />
        </div>
        <div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">Productivity Score</div>
        <div className="mt-0.5 text-xs text-slate-300">
          {score >= 80 ? 'Excellent flow' : score >= 60 ? 'On track' : 'Needs focus'}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  suffix,
  accent,
  progress,
  compact,
}: {
  icon: typeof Gauge;
  label: string;
  value: string;
  suffix?: string;
  accent: string;
  progress?: number;
  compact?: boolean;
}) {
  return (
    <div className="glass card-hover group relative overflow-hidden rounded-2xl p-5 hover:border-white/20">
      <div className={`absolute -right-6 -top-6 h-20 w-20 rounded-full bg-gradient-to-br ${accent} opacity-20 blur-2xl transition duration-500 group-hover:opacity-50 group-hover:scale-125`} />
      <div className="relative">
        <div className={`mb-3 grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br ${accent} shadow-lg`}>
          <Icon className="h-4 w-4 text-white" />
        </div>
        <div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">{label}</div>
        <div className={`mt-1 font-display font-700 text-white ${compact ? 'text-base' : 'text-2xl'}`}>
          {value}
          {suffix && <span className="text-sm text-slate-400">{suffix}</span>}
        </div>
        {typeof progress === 'number' && (
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full rounded-full bg-gradient-to-r ${accent}`}
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- AI Decision Trail ---------------- */
function DecisionTrail({ tasks }: { tasks: Task[] }) {
  const [open, setOpen] = useState(false);
  const ranked = [...tasks].sort(
    (a, b) =>
      b.urgency * 0.35 + b.importance * 0.35 + b.deadlinePressure * 0.3 -
      (a.urgency * 0.35 + a.importance * 0.35 + a.deadlinePressure * 0.3)
  );

  return (
    <div className="mt-6 animate-slideUp">
      <div className="glass-strong gradient-border overflow-hidden rounded-2xl">
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left transition hover:bg-white/[0.03] focus-ring"
        >
          <span className="inline-flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-electric-600/30 to-cyan-500/20 ring-1 ring-white/10">
              <Brain className="h-4 w-4 text-cyan-300" />
            </span>
            <span>
              <span className="font-display text-sm font-600 text-white">
                Why AI prioritized this
              </span>
              <span className="mt-0.5 block text-[11px] text-slate-400">
                A transparent look at how each task was ranked
              </span>
            </span>
          </span>
          <ChevronDown
            className={`h-5 w-5 shrink-0 text-slate-400 transition-transform duration-300 ${
              open ? 'rotate-180' : ''
            }`}
          />
        </button>

        {open && (
          <div className="border-t border-white/5 p-5 animate-fadeIn">
            <div className="mb-4 flex items-center gap-2 text-[11px] uppercase tracking-[0.16em] text-slate-500">
              <Sparkles className="h-3.5 w-3.5 text-electric-400" />
              Decision Trail
            </div>
            <ol className="space-y-3">
              {ranked.map((t, i) => (
                <li
                  key={t.id}
                  className="rounded-xl border border-white/5 bg-white/[0.02] p-4"
                  style={{ animation: `slideUp 0.5s cubic-bezier(0.22,1,0.36,1) ${i * 0.08}s both` }}
                >
                  <div className="flex items-start gap-3">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-electric-600 to-cyan-500 text-xs font-700 text-white shadow-lg">
                      {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <span className="font-display text-sm font-600 text-white">
                          {t.title}
                        </span>
                        <span
                          className={`rounded-full border px-2 py-0.5 text-[9px] font-600 uppercase tracking-wider ${
                            PRIORITY_META[t.priority].badge
                          }`}
                        >
                          {PRIORITY_META[t.priority].label}
                        </span>
                      </div>

                      {/* Scoring grid */}
                      <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-4">
                        <TrailScore label="Urgency" value={t.urgency} color="from-rose-500 to-orange-400" />
                        <TrailScore label="Impact" value={t.importance} color="from-electric-500 to-cyan-400" />
                        <TrailScore label="Effort" value={t.effort} color="from-amber-500 to-yellow-400" invert />
                        <TrailScore label="Deadline pressure" value={t.deadlinePressure} color="from-fuchsia-500 to-rose-400" />
                      </div>

                      {/* Explanation */}
                      <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-slate-300">
                        <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-300" />
                        <span>
                          <span className="font-600 text-electric-200">Why here · </span>
                          {t.trailExplanation}
                        </span>
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ol>
            <p className="mt-4 flex items-center gap-2 text-[11px] text-slate-500">
              <Activity className="h-3.5 w-3.5 text-cyan-400" />
              Scores blend urgency, impact, effort, and deadline pressure — higher effort lowers priority when everything else is equal.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function TrailScore({
  label,
  value,
  color,
  invert,
}: {
  label: string;
  value: number;
  color: string;
  invert?: boolean;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[10px] text-slate-400">
        <span>{label}</span>
        <span className="font-600 text-slate-200">{value}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
        <div
          className={`h-full origin-left rounded-full bg-gradient-to-r ${color}`}
          style={{
            width: `${value}%`,
            animation: 'barFill 0.8s cubic-bezier(0.22,1,0.36,1) both',
          }}
        />
      </div>
      {invert && (
        <div className="mt-0.5 text-[9px] text-slate-500">higher = more work</div>
      )}
    </div>
  );
}

/* ---------------- Task Card ---------------- */
function TaskCard({
  task,
  index,
  onFocus,
}: {
  task: Task;
  index: number;
  onFocus: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const meta = PRIORITY_META[task.priority];

  return (
    <div
      className={`glass-strong card-hover priority-rail group relative overflow-hidden rounded-2xl p-5 pl-6 hover:border-white/20 ${meta.ring}`}
      style={{
        animation: `slideUp 0.6s cubic-bezier(0.22,1,0.36,1) ${index * 0.1}s both`,
        ['--rail' as string]: RAIL[task.priority].rail,
        ['--rail-glow' as string]: RAIL[task.priority].glow,
      }}
    >
      <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${meta.gradient} opacity-70`} />
      <div className="relative">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${meta.dot} shadow-[0_0_8px_currentColor]`} />
              <span
                className={`rounded-full border px-2.5 py-0.5 text-[10px] font-600 uppercase tracking-wider ${meta.badge}`}
              >
                {meta.label}
              </span>
            </div>
            <h4 className="mt-3 font-display text-lg font-600 leading-snug text-white">
              {task.title}
            </h4>
          </div>
        </div>

        {/* Meta row */}
        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-300">
          <span className="inline-flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-cyan-300" /> {task.durationLabel}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <CalendarClock className="h-3.5 w-3.5 text-electric-300" /> {task.deadline}
          </span>
        </div>

        {/* Scores */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          <ScoreBar label="Urgency" value={task.urgency} color="from-rose-500 to-orange-400" />
          <ScoreBar label="Importance" value={task.importance} color="from-electric-500 to-cyan-400" />
        </div>

        {/* Reasoning */}
        <div className="mt-4 flex gap-2 rounded-xl border border-white/5 bg-white/[0.03] p-3">
          <Brain className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
          <p className="text-xs leading-relaxed text-slate-300">
            <span className="font-600 text-electric-200">AI reasoning · </span>
            {task.reasoning}
          </p>
        </div>

        {/* Steps toggle */}
        <button
          onClick={() => setExpanded((v) => !v)}
          className="mt-4 flex w-full items-center justify-between rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5 text-xs text-slate-300 transition hover:bg-white/[0.06] focus-ring"
        >
          <span className="inline-flex items-center gap-2">
            <ListChecks className="h-3.5 w-3.5 text-cyan-300" />
            {task.steps.length} action steps
          </span>
          <ChevronDown
            className={`h-4 w-4 transition ${expanded ? 'rotate-180' : ''}`}
          />
        </button>
        {expanded && (
          <ol className="mt-3 space-y-2 animate-fadeIn">
            {task.steps.map((s, i) => (
              <li
                key={s}
                className="flex items-center gap-3 rounded-lg border border-white/5 bg-ink-900/40 px-3 py-2 text-sm text-slate-200"
              >
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-electric-500/20 text-[10px] font-600 text-electric-200">
                  {i + 1}
                </span>
                {s}
              </li>
            ))}
          </ol>
        )}

        {/* Focus button */}
        <button
          onClick={onFocus}
          className="btn-primary mt-4 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-600 text-white focus-ring"
        >
          <Focus className="h-4 w-4" /> Start Focus Mode
        </button>
      </div>
    </div>
  );
}

function ScoreBar({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-[11px] text-slate-400">
        <span>{label}</span>
        <span className="font-600 text-slate-200">{value}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
        <div
          className={`h-full origin-left rounded-full bg-gradient-to-r ${color}`}
          style={{ width: `${value}%`, animation: 'barFill 0.9s cubic-bezier(0.22,1,0.36,1) both' }}
        />
      </div>
    </div>
  );
}

/* ---------------- Focus Modal ---------------- */
function FocusModal({ task, onClose }: { task: Task; onClose: () => void }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(true);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [running]);

  const mm = String(Math.floor(seconds / 60)).padStart(2, '0');
  const ss = String(seconds % 60).padStart(2, '0');
  const progress = ((25 * 60 - seconds) / (25 * 60)) * 100;
  const allDone = stepIndex >= task.steps.length;

  const completeStep = () => {
    if (stepIndex < task.steps.length - 1) {
      setStepIndex((i) => i + 1);
    } else {
      setStepIndex(task.steps.length);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-ink-950/85 backdrop-blur-md animate-fadeIn"
        onClick={onClose}
      />
      <div className="relative w-full max-w-lg animate-scaleIn">
        <div className="glass-strong gradient-border relative overflow-hidden rounded-3xl p-6 sm:p-8">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-56 w-56 -translate-x-1/2 animate-pulseGlow rounded-full bg-electric-600/30 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 right-0 h-40 w-40 rounded-full bg-cyan-500/15 blur-3xl" />

          <button
            onClick={onClose}
            className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full border border-white/10 bg-white/5 text-slate-300 transition hover:bg-white/10 hover:text-white focus-ring"
          >
            <X className="h-4 w-4" />
          </button>

          <div className="relative">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-electric-300">
              <Focus className="h-3.5 w-3.5" /> Focus Mode
            </div>
            <h3 className="mt-2 font-display text-2xl font-700 text-white">{task.title}</h3>

            {/* Timer */}
            <div className="relative mx-auto mt-8 grid h-52 w-52 place-items-center">
              <div className={`absolute inset-8 rounded-full bg-gradient-to-br from-electric-600/20 to-cyan-500/20 blur-xl ${running ? 'animate-pulseGlow' : ''}`} />
              <svg className="absolute inset-0 -rotate-90" viewBox="0 0 200 200">
                <circle cx="100" cy="100" r="90" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
                <circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke="url(#focusGrad)"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={2 * Math.PI * 90}
                  strokeDashoffset={2 * Math.PI * 90 * (1 - progress / 100)}
                  style={{ transition: 'stroke-dashoffset 1s linear' }}
                />
                <defs>
                  <linearGradient id="focusGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#22d3ee" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="relative text-center">
                <div className="font-display text-5xl font-700 tabular-nums text-white drop-shadow-[0_0_20px_rgba(139,92,246,0.4)]">
                  {mm}:{ss}
                </div>
                <div className="mt-1.5 inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-slate-400">
                  <span className={`h-1.5 w-1.5 rounded-full ${running ? 'animate-pulse bg-cyan-400' : 'bg-slate-500'}`} />
                  {running ? 'In focus' : 'Paused'}
                </div>
              </div>
            </div>

            {/* Step progress dots */}
            <div className="mt-5 flex items-center justify-center gap-2">
              {task.steps.map((_, i) => (
                <div
                  key={i}
                  className={`h-1.5 rounded-full transition-all duration-500 ${
                    i < stepIndex
                      ? 'w-8 bg-emerald-400'
                      : i === stepIndex
                      ? 'w-10 bg-gradient-to-r from-electric-400 to-cyan-400'
                      : 'w-4 bg-white/15'
                  }`}
                />
              ))}
            </div>

            {/* Current step */}
            <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <div className="text-[11px] uppercase tracking-[0.16em] text-slate-400">
                Current step {Math.min(stepIndex + 1, task.steps.length)} / {task.steps.length}
              </div>
              {allDone ? (
                <div className="mt-2 flex items-center gap-2 text-lg font-600 text-emerald-300 animate-scaleIn">
                  <CheckCircle2 className="h-5 w-5" /> All steps complete
                </div>
              ) : (
                <div className="mt-2 text-lg font-600 text-white">{task.steps[stepIndex]}</div>
              )}
            </div>

            {/* AI coaching */}
            <div className="mt-4 flex gap-3 rounded-2xl border border-electric-400/20 bg-electric-500/10 p-4">
              <Brain className="mt-0.5 h-4 w-4 shrink-0 text-electric-300" />
              <p className="text-sm leading-relaxed text-slate-200">{FOCUS_COACHING.default}</p>
            </div>

            {/* Controls */}
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button
                onClick={() => setRunning((r) => !r)}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-600 text-slate-200 transition hover:-translate-y-0.5 hover:bg-white/10 focus-ring"
              >
                {running ? <Timer className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                {running ? 'Pause' : 'Resume'}
              </button>
              <button
                onClick={completeStep}
                disabled={allDone}
                className="btn-primary relative flex flex-1 items-center justify-center gap-2 overflow-hidden rounded-xl px-4 py-3 text-sm font-600 text-white disabled:opacity-40 focus-ring"
              >
                <CheckCircle2 className="h-4 w-4" />
                {allDone ? 'Step complete' : 'Complete Step'}
              </button>
              <button
                onClick={onClose}
                className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-600 text-slate-300 transition hover:bg-white/10 focus-ring sm:px-5"
              >
                <X className="h-4 w-4" /> Exit
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Footer ---------------- */
function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/5 py-8">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 text-xs text-slate-500 sm:flex-row sm:px-8">
        <div className="flex items-center gap-2">
          <Sparkles className="h-3.5 w-3.5 text-electric-400" />
          FlowPilot AI · Your AI Chief of Staff
        </div>
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-1.5">
            <Activity className="h-3.5 w-3.5 text-cyan-400" /> Built for the hackathon
          </span>
        </div>
      </div>
    </footer>
  );
}
