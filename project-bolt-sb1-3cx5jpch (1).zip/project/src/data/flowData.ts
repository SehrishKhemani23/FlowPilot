export type Priority = 'high' | 'important' | 'quick';

export interface Task {
  id: string;
  title: string;
  priority: Priority;
  durationLabel: string;
  durationMinutes: number;
  deadline: string;
  urgency: number; // 1-100
  importance: number; // 1-100 (Impact)
  effort: number; // 1-100 (higher = more effort required)
  deadlinePressure: number; // 1-100
  reasoning: string;
  trailExplanation: string; // human-readable "why placed here"
  steps: string[];
}

export const PRIORITY_META: Record<
  Priority,
  { label: string; group: string; gradient: string; badge: string; dot: string; ring: string }
> = {
  high: {
    label: 'High Priority',
    group: 'HIGH PRIORITY',
    gradient: 'from-rose-500/20 via-red-500/10 to-transparent',
    badge: 'bg-rose-500/15 text-rose-300 border-rose-400/30',
    dot: 'bg-rose-400',
    ring: 'shadow-[0_0_30px_-8px_rgba(244,63,94,0.5)]',
  },
  important: {
    label: 'Important',
    group: 'IMPORTANT',
    gradient: 'from-amber-500/20 via-orange-500/10 to-transparent',
    badge: 'bg-amber-500/15 text-amber-300 border-amber-400/30',
    dot: 'bg-amber-400',
    ring: 'shadow-[0_0_30px_-8px_rgba(245,158,11,0.45)]',
  },
  quick: {
    label: 'Quick Win',
    group: 'QUICK WINS',
    gradient: 'from-emerald-500/20 via-teal-500/10 to-transparent',
    badge: 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30',
    dot: 'bg-emerald-400',
    ring: 'shadow-[0_0_30px_-8px_rgba(16,185,129,0.45)]',
  },
};

export const DEMO_INPUT =
  'I have an AI presentation tomorrow morning, a programming assignment due tonight, three emails to reply to, a meeting at 5 PM, and I need to prepare for an interview.';

export const DEMO_TASKS: Task[] = [
  {
    id: 't1',
    title: 'Prepare AI Presentation',
    priority: 'high',
    durationLabel: '2h 30m',
    durationMinutes: 150,
    deadline: 'Tomorrow morning',
    urgency: 92,
    importance: 88,
    effort: 80,
    deadlinePressure: 90,
    reasoning: 'High impact and close deadline — this is the single biggest lever for tomorrow.',
    trailExplanation: 'Placed first because it has a close deadline, high impact, and requires focused work.',
    steps: ['Create outline', 'Prepare slides', 'Practice presentation'],
  },
  {
    id: 't2',
    title: 'Complete Programming Assignment',
    priority: 'high',
    durationLabel: '3h',
    durationMinutes: 180,
    deadline: 'Due tonight',
    urgency: 96,
    importance: 82,
    effort: 85,
    deadlinePressure: 95,
    reasoning: 'Deadline is today and requires deep work — start before energy drops.',
    trailExplanation: 'Due tonight and needs deep focus — scheduled early so it fits before your energy fades.',
    steps: ['Review requirements', 'Implement solution', 'Test and submit'],
  },
  {
    id: 't3',
    title: 'Prepare for Interview',
    priority: 'important',
    durationLabel: '1h',
    durationMinutes: 60,
    deadline: 'Tomorrow',
    urgency: 70,
    importance: 90,
    effort: 55,
    deadlinePressure: 60,
    reasoning: 'Important career preparation — high long-term value, moderate urgency.',
    trailExplanation: 'High long-term value with a softer deadline — placed after urgent work, before the day ends.',
    steps: ['Review common questions', 'Prepare project explanations', 'Practice answers'],
  },
  {
    id: 't4',
    title: 'Reply to Emails',
    priority: 'quick',
    durationLabel: '30m',
    durationMinutes: 30,
    deadline: 'Today',
    urgency: 64,
    importance: 55,
    effort: 25,
    deadlinePressure: 50,
    reasoning: 'Small task that can be completed quickly — clear it to free mental space.',
    trailExplanation: 'A quick win — low effort and low pressure, perfect to clear mental space between bigger tasks.',
    steps: ['Review emails', 'Prioritize replies', 'Send responses'],
  },
];

export const PROCESSING_STEPS = [
  { label: 'Reading your thoughts...', icon: 'scan' },
  { label: 'Finding priorities...', icon: 'target' },
  { label: 'Estimating your time...', icon: 'clock' },
  { label: 'Building your action plan...', icon: 'sparkles' },
];

export const FOCUS_COACHING: Record<string, string> = {
  default:
    'You have everything you need to start. Single-task this — close every other tab. The next 25 minutes belong to this one step.',
};
