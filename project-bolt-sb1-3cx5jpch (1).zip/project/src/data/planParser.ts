import type { Priority, Task } from './flowData';

/* ------------------------------------------------------------------ *
 *  Local intelligent fallback parser
 *  No API key required — analyzes the user's raw text and produces a
 *  dynamic, prioritized action plan based on keyword + content signals.
 * ------------------------------------------------------------------ */

interface RawItem {
  text: string;
  kind: string;
  priority: Priority;
  urgency: number;
  importance: number;
  effort: number;
  deadlinePressure: number;
  deadline: string;
  durationMinutes: number;
}

const KIND_PROFILES: Record<
  string,
  { priority: Priority; importance: number; effort: number; minutes: number; steps: string[] }
> = {
  exam: { priority: 'high', importance: 92, effort: 80, minutes: 180, steps: ['Review syllabus topics', 'Practice past questions', 'Summarize key concepts', 'Self-test weak areas'] },
  study: { priority: 'high', importance: 85, effort: 70, minutes: 120, steps: ['Read materials', 'Take notes', 'Practice exercises', 'Review summaries'] },
  test: { priority: 'high', importance: 88, effort: 75, minutes: 150, steps: ['Review notes', 'Practice problems', 'Time a mock run'] },
  assignment: { priority: 'high', importance: 82, effort: 85, minutes: 180, steps: ['Read requirements', 'Outline approach', 'Implement solution', 'Review and submit'] },
  homework: { priority: 'high', importance: 75, effort: 60, minutes: 90, steps: ['Read instructions', 'Work through problems', 'Double-check answers'] },
  project: { priority: 'important', importance: 86, effort: 90, minutes: 240, steps: ['Define scope', 'Break into milestones', 'Build first piece', 'Review progress'] },
  presentation: { priority: 'high', importance: 88, effort: 80, minutes: 150, steps: ['Create outline', 'Prepare slides', 'Rehearse out loud'] },
  slides: { priority: 'high', importance: 80, effort: 65, minutes: 90, steps: ['Draft content', 'Design slides', 'Review flow'] },
  interview: { priority: 'important', importance: 90, effort: 55, minutes: 60, steps: ['Research the company', 'Prepare project stories', 'Practice common questions'] },
  meeting: { priority: 'important', importance: 72, effort: 40, minutes: 45, steps: ['Set an agenda', 'Gather materials', 'Note key talking points'] },
  email: { priority: 'quick', importance: 55, effort: 25, minutes: 30, steps: ['Review inbox', 'Prioritize replies', 'Send responses'] },
  emails: { priority: 'quick', importance: 55, effort: 25, minutes: 30, steps: ['Review inbox', 'Prioritize replies', 'Send responses'] },
  reply: { priority: 'quick', importance: 50, effort: 20, minutes: 20, steps: ['Read messages', 'Draft replies', 'Send'] },
  website: { priority: 'important', importance: 84, effort: 95, minutes: 300, steps: ['List remaining features', 'Build next section', 'Test in browser', 'Fix issues'] },
  code: { priority: 'important', importance: 80, effort: 80, minutes: 180, steps: ['Understand requirements', 'Write implementation', 'Test and debug'] },
  bug: { priority: 'high', importance: 78, effort: 60, minutes: 90, steps: ['Reproduce issue', 'Identify cause', 'Fix and verify'] },
  report: { priority: 'important', importance: 80, effort: 70, minutes: 150, steps: ['Gather data', 'Draft sections', 'Review and format'] },
  essay: { priority: 'important', importance: 82, effort: 75, minutes: 180, steps: ['Plan argument', 'Draft body', 'Write intro & conclusion', 'Proofread'] },
  workout: { priority: 'quick', importance: 60, effort: 50, minutes: 60, steps: ['Warm up', 'Main session', 'Cool down'] },
  laundry: { priority: 'quick', importance: 45, effort: 30, minutes: 45, steps: ['Sort clothes', 'Run wash', 'Dry and fold'] },
  grocery: { priority: 'quick', importance: 50, effort: 30, minutes: 45, steps: ['Make a list', 'Shop', 'Unpack and store'] },
  groceries: { priority: 'quick', importance: 50, effort: 30, minutes: 45, steps: ['Make a list', 'Shop', 'Unpack and store'] },
  call: { priority: 'quick', importance: 60, effort: 20, minutes: 20, steps: ['Prepare what to say', 'Make the call', 'Note outcomes'] },
  plan: { priority: 'important', importance: 78, effort: 45, minutes: 60, steps: ['List goals', 'Sequence steps', 'Set checkpoints'] },
  read: { priority: 'quick', importance: 60, effort: 40, minutes: 60, steps: ['Find material', 'Read and annotate', 'Summarize takeaways'] },
  write: { priority: 'important', importance: 82, effort: 80, minutes: 150, steps: ['Outline', 'Draft', 'Revise'] },
  default: { priority: 'important', importance: 70, effort: 60, minutes: 90, steps: ['Clarify the goal', 'Take the first step', 'Review results'] },
};

const KIND_KEYWORDS: { kind: string; words: string[] }[] = [
  { kind: 'exam', words: ['exam', 'final', 'midterm', 'quiz', 'test'] },
  { kind: 'study', words: ['study', 'studying', 'revise', 'revision', 'learn', 'memorize'] },
  { kind: 'assignment', words: ['assignment', 'homework', 'coursework', 'problem set'] },
  { kind: 'project', words: ['project', 'build', 'develop', 'ship'] },
  { kind: 'presentation', words: ['presentation', 'present', 'pitch', 'talk', 'demo'] },
  { kind: 'slides', words: ['slides', 'deck', 'slide'] },
  { kind: 'interview', words: ['interview', 'interviewing'] },
  { kind: 'meeting', words: ['meeting', 'meet', 'call with', 'sync', 'standup'] },
  { kind: 'email', words: ['email', 'emails', 'inbox', 'reply to', 'respond to'] },
  { kind: 'website', words: ['website', 'site', 'landing page', 'web app', 'frontend'] },
  { kind: 'code', words: ['code', 'coding', 'program', 'programming', 'implement', 'feature'] },
  { kind: 'bug', words: ['bug', 'fix', 'debug', 'error', 'broken'] },
  { kind: 'report', words: ['report', 'document', 'documentation'] },
  { kind: 'essay', words: ['essay', 'paper', 'article', 'blog'] },
  { kind: 'workout', words: ['workout', 'exercise', 'gym', 'run', 'training'] },
  { kind: 'laundry', words: ['laundry', 'wash clothes'] },
  { kind: 'grocery', words: ['grocery', 'groceries', 'shopping'] },
  { kind: 'call', words: ['call', 'phone'] },
  { kind: 'read', words: ['read', 'reading'] },
  { kind: 'write', words: ['write', 'writing', 'draft'] },
];

const DEADLINE_PATTERNS: { regex: RegExp; label: string; pressure: number; urgencyBoost: number }[] = [
  { regex: /\btonight\b/i, label: 'Due tonight', pressure: 95, urgencyBoost: 30 },
  { regex: /\btoday\b/i, label: 'Today', pressure: 90, urgencyBoost: 28 },
  { regex: /\btomorrow morning\b/i, label: 'Tomorrow morning', pressure: 88, urgencyBoost: 25 },
  { regex: /\btomorrow\b/i, label: 'Tomorrow', pressure: 80, urgencyBoost: 22 },
  { regex: /\bthis (morning|afternoon|evening)\b/i, label: 'Today', pressure: 92, urgencyBoost: 28 },
  { regex: /\bthis week\b/i, label: 'This week', pressure: 60, urgencyBoost: 12 },
  { regex: /\bnext week\b/i, label: 'Next week', pressure: 40, urgencyBoost: 5 },
  { regex: /\bby (\d{1,2}(?:am|pm)?)\b/i, label: 'Today', pressure: 85, urgencyBoost: 20 },
  { regex: /\bat (\d{1,2}(?:am|pm)?)\b/i, label: 'Today', pressure: 85, urgencyBoost: 20 },
  { regex: /\b(\d{1,2})\s*(am|pm)\b/i, label: 'Today', pressure: 85, urgencyBoost: 18 },
  { regex: /\basap\b|\burgent\b|\bnow\b/i, label: 'ASAP', pressure: 98, urgencyBoost: 35 },
];

const URGENCY_WORDS = /\b(urgent|asap|immediately|critical|important|must|need to|have to|got to)\b/i;
const QUANTITY = /\b(\d+)\s+(emails?|calls?|tasks?|items?|pages?|chapters?|problems?|bugs?)\b/i;

function detectKind(text: string): string {
  const lower = text.toLowerCase();
  for (const { kind, words } of KIND_KEYWORDS) {
    if (words.some((w) => lower.includes(w))) return kind;
  }
  return 'default';
}

function detectDeadline(text: string) {
  for (const p of DEADLINE_PATTERNS) {
    if (p.regex.test(text)) return p;
  }
  return null;
}

function titleCase(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function splitIntoItems(input: string): string[] {
  // Split on commas, "and", line breaks, semicolons, bullet markers, and conjunctions
  const parts = input
    .split(/\n|;|•|\b(?:and then|then|also|plus|as well as)\b|,(?=\s)|\band\b/i)
    .map((s) => s.trim())
    .filter((s) => s.length > 2 && s.length < 200);
  return parts.length > 1 ? parts : [input.trim()];
}

function makeTitle(text: string, kind: string): string {
  let t = text
    .replace(/\b(i need to|i have to|i must|i want to|i should|i've got to|got to|need to|have to|lets? me|let me)\b/gi, '')
    .replace(/\b(please|kindly|just|really|very)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
  t = t.replace(/^(to|a|an|the)\s+/i, '');
  // Capitalize first letter
  if (t.length === 0) t = text.trim();
  if (t.length > 60) t = t.slice(0, 57).trim() + '…';
  return titleCase(t) || `Work on ${kind}`;
}

function clamp(n: number, min = 1, max = 100): number {
  return Math.max(min, Math.min(max, Math.round(n)));
}

function buildReasoning(item: RawItem): { reasoning: string; trailExplanation: string } {
  const parts: string[] = [];
  if (item.deadlinePressure >= 85) parts.push('a close deadline');
  else if (item.deadlinePressure >= 65) parts.push('a near-term deadline');
  else if (item.deadlinePressure >= 40) parts.push('a moderate deadline');
  else parts.push('a flexible deadline');

  if (item.importance >= 85) parts.push('high impact');
  else if (item.importance >= 70) parts.push('solid impact');
  else parts.push('moderate impact');

  if (item.effort >= 75) parts.push('focused work');
  else if (item.effort <= 35) parts.push('a quick win');
  else parts.push('steady effort');

  const reasoning = `${titleCase(parts[0])} and ${parts[1]} — prioritized based on ${parts[2]}.`;
  const rank = item.priority === 'high' ? 'early' : item.priority === 'quick' ? 'as a quick win between bigger tasks' : 'after the urgent work';
  const trailExplanation = `Placed ${rank} because it has ${parts.join(', ')}.`;
  return { reasoning, trailExplanation };
}

function formatDuration(min: number): string {
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (h && m) return `${h}h ${m}m`;
  if (h) return `${h}h`;
  return `${m}m`;
}

function buildItem(text: string): RawItem {
  const kind = detectKind(text);
  const profile = KIND_PROFILES[kind] ?? KIND_PROFILES.default;
  const deadline = detectDeadline(text);

  let urgency = 50 + (deadline?.urgencyBoost ?? 0);
  if (URGENCY_WORDS.test(text)) urgency += 15;
  urgency = clamp(urgency);

  const importance = profile.importance;
  const effort = profile.effort;
  let deadlinePressure = deadline?.pressure ?? clamp(30 + urgency * 0.2);
  if (URGENCY_WORDS.test(text)) deadlinePressure = clamp(deadlinePressure + 10);

  // Quantity modifier — more items = more minutes, slightly more effort
  const qMatch = text.match(QUANTITY);
  let minutes = profile.minutes;
  if (qMatch) {
    const qty = parseInt(qMatch[1], 10);
    minutes = Math.round(minutes * Math.min(2, 0.6 + qty * 0.15));
    minutes = Math.min(480, minutes);
  }

  const priority: Priority =
    deadline && deadline.pressure >= 85 ? 'high' : profile.priority;

  return {
    text,
    kind,
    priority,
    urgency,
    importance,
    effort,
    deadlinePressure,
    deadline: deadline?.label ?? 'When you can',
    durationMinutes: minutes,
  };
}

export function generatePlan(input: string): Task[] {
  const trimmed = input.trim();
  if (!trimmed) return [];

  const items = splitIntoItems(trimmed).map(buildItem);

  // Sort by blended priority score so the plan reads in priority order
  const scored = items.map((item, idx) => {
    const score =
      item.urgency * 0.35 + item.importance * 0.35 + item.deadlinePressure * 0.3 - item.effort * 0.1;
    return { item, score, idx };
  });
  scored.sort((a, b) => b.score - a.score);

  const tasks: Task[] = scored.map(({ item }, i) => {
    const profile = KIND_PROFILES[item.kind] ?? KIND_PROFILES.default;
    const { reasoning, trailExplanation } = buildReasoning(item);
    return {
      id: `task-${i + 1}`,
      title: makeTitle(item.text, item.kind),
      priority: item.priority,
      durationLabel: formatDuration(item.durationMinutes),
      durationMinutes: item.durationMinutes,
      deadline: item.deadline,
      urgency: item.urgency,
      importance: item.importance,
      effort: item.effort,
      deadlinePressure: item.deadlinePressure,
      reasoning,
      trailExplanation,
      steps: profile.steps,
    };
  });

  return tasks;
}

/* Demo examples for the input screen prompt buttons */
export const EXAMPLE_PROMPTS: { label: string; text: string }[] = [
  {
    label: 'Exam prep',
    text: 'I have an exam tomorrow and need to study Python. I also have a few emails to reply to.',
  },
  {
    label: 'Busy day',
    text: 'I need to finish my website, reply to emails, and prepare for a meeting at 5 PM.',
  },
  {
    label: 'Project sprint',
    text: 'Finish the frontend for my web app, fix a bug in the login flow, and write a short report.',
  },
  {
    label: 'Mixed day',
    text: 'Study for my interview tomorrow, do laundry, go grocery shopping, and read a chapter of my book.',
  },
];
